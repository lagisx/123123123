package com.boxing.config;

/** Ключи и адрес проекта Supabase. Заполните своими значениями (Project Settings -> API). */
public final class SupabaseConfig {
    private SupabaseConfig() {}

    public static final String URL = "https://YOUR-PROJECT-ID.supabase.co";
    /** Публичный (anon) ключ — используется приложением. */
    public static final String ANON_KEY = "YOUR_ANON_KEY";
    /** Сервисный ключ (service_role) — НИКОГДА не публикуйте его. Только для админ-операций. */
    public static final String SERVICE_KEY = "YOUR_SERVICE_ROLE_KEY";
}
